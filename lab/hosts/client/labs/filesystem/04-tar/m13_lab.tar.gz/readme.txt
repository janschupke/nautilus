M13 readme
